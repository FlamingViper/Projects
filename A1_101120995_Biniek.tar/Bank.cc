#include <iostream>
#include <string>
using namespace std;
#include "Bank.h"

Bank::Bank(string n){

  bName=n;
  pos=0;
  cout<<"Bank "<<bName<<endl;
}


Bank::~Bank(){
  for(int i=0;i<pos;i++){
    delete num[i];
  }
}

bool Bank::addCust(Customer* c){
  if(b.add(c)==true){
    return true;
  }
  return false;
}

bool Bank::addAcct(int custId,Account* acct){

  Customer* c;
  b.find(custId,&c);

  if(c==NULL||pos>=MAX_GIANT){
    return false;
  }
  num[pos]=acct;
  c->addAcct(acct);
  num[pos]->setCustomer(c);
  pos++;

  return true; 

}

bool Bank::debit(int acctNum,float amount){
  for(int i=0;i<pos;++i){
    if(num[i]->getNumber()==acctNum){
      num[i]->debit(amount);
      return true;
    }
  }
  cout<<"Error: Account "<<acctNum<<" not found"<<endl;
  return false;


}

bool Bank::credit(int acctNum,float amount){
  for(int i=0;i<pos;++i){
    if(num[i]->getNumber()==acctNum){
      num[i]->credit(amount);
      return true;
    }
  }
  cout<<"Error: Account "<<acctNum<<" not found"<<endl;
  return false;

}

void Bank::print(){
  cout<<"Accounts:"<<endl;
  for(int i=0;i<pos;++i){
    num[i]->print();	
  }
  cout<<endl;
  cout<<"Customers:"<<endl;
  b.print();

}

