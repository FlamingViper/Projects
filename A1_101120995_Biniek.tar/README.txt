Program Author:

Artin Biniek
101120995

Purpose:

The purpose of this program is to managage the customers of a bank and their bank accounts
and process their debit and credit transactions onto those accounts

List of source and header files:

Account.cc, Account.h, Customer.cc, Customer.h, custArray.cc, custArray.h, Bank.cc, Bank.h,
main.cc

Compliation and launching instructions:

make(by putting the command make in the specified directory it will compile the program)

./A1 (A1 is the name of the executable and to launch it is ./A1)
