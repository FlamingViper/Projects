#ifndef CUSTARRAY_H
#define CUSTARRAY_H
#define MAX_CUST 64
#include "Customer.h"

//The CustArray classes purpose is to be a collection class for the Customer class

class custArray{
public:
  custArray();
  ~custArray();
  bool add(Customer*);
  void find(int,Customer**);
  void print();
private:
  Customer* a[MAX_CUST];
  int index;
};

#endif
