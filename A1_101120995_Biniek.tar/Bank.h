#ifndef BANK_H
#define BANK_H
#define MAX_GIANT 50
#include "custArray.h"
#include "Account.h"
#include "Customer.h"

/*The purpose of the bank class is to stroe two master collections one thats customers in the
bank and another thats accounts.
*/

class Bank{
public:
  Bank(string="Unknown");
  ~Bank();
  bool addCust(Customer*);
  bool addAcct(int,Account*);
  bool debit(int,float);
  bool credit(int,float);
  void print();


private:
  string bName;
  Account* num[MAX_GIANT];
  custArray b;
  int pos;



};

#endif
