#ifndef CUSTOMER_H
#define CUSTOMER_H
#define MAX_SIZE 16
class Account;

/*The purpose of the customer class is to create a customer object that
contains an array of account pointer objects.
*/
class Customer{
 public:
  Customer(int=0,string="Unknown");
  int getId();
  bool addAcct(Account*);
  void print();

 private:
  int id;
  string name;
  Account* collection[MAX_SIZE];
  int current;

};



#endif
