#include <iostream>
using namespace std;
#include "Account.h"
Account::Account(int n,float b){
  number=n;
  balance=b;
  
}

int Account::getNumber(){

  return number;
}

bool Account::debit(float amount){
  if(amount>balance || amount<0 ){
    cout<<"Error: can not be debited by $"<<amount<<endl;
    return false;
  }
  balance-=amount;
  return true;
}

bool Account::credit(float amount){
  if(amount<0){
    cout<<"Error: cannot be credited by $"<<amount<<endl;
    return false;
  }
  balance+=amount;
  return true;

}


void Account:: setCustomer(Customer* c){
  owner=c;
}



void Account::print(){
        
  cout<<"Id: "<<owner->getId()<<" Account number: "<<number<<" has a balance of:    $"<<balance<<endl;
        
}

