#include <iostream>
using namespace std;
#include "custArray.h"

custArray::custArray(){
  index=0;

}

custArray::~custArray(){
  for(int i=0;i<index;++i){
    delete a[i];
  }	

}

bool custArray::add(Customer* c){
  if(index>=MAX_CUST){
    return false;
  }
  a[index++]=c;
  return true;
}

void custArray::find(int id,Customer** c){
  for(int i=0;i<index;++i){
    if(a[i]->getId()==id){
      *c=a[i]; 
      return;            
    }
  }
  *c=NULL;       
}

void custArray::print(){
  for(int i=0;i<index;++i){
    a[i]->print();
  }

}




