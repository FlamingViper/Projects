#include <iostream>
#include <string>
using namespace std;
#include "Customer.h"
#include "Account.h"
Customer::Customer(int i,string n){
  id=i;
  name=n;
  current=0;
}

int Customer::getId(){
  return id;
}

bool Customer::addAcct(Account* a){
  if(current>=MAX_SIZE){
    return false;
  }
  collection[current++]=a;
  return true;
}

void Customer::print(){
  cout<<name<<endl;
  if(current==0){
    cout<<"No Accounts"<<endl<<endl;;
    return;
  }
  
  for(int i=0;i<current;i++){
    collection[i]->print();
    cout<<endl;
  }
}


