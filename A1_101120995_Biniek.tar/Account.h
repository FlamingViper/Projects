#ifndef ACCOUNT_H
#define ACCOUNT_H
#include "Customer.h"

//The purpose of the account class is create account objects 

class Account{
public:
  Account(int=0,float=0.0);
  int getNumber();
  void setCustomer(Customer*);
  bool debit(float);
  bool credit(float);
  void print();
private:
 int number;
 float balance;
 Customer* owner;


};

#endif
